

/*
      ============================== blog carousel =======================
*/
$('.owl-carousel').owlCarousel({
      loop:true,
      margin:10,
      responsiveClass:true,
      nav : true,
      autoplay: true,
      autoplayTimeout : 4000,
      dots : false,
      responsive:{
          0:{
              items:1,
          },
          576:{
              items:1,
          },
          768:{
              items:2,
          },
          992:{
              items:2,
          },
          1200:{
              items:3,
          },
          1400:{
              items:3,
          },
      }
});
/*
      ============================== blog carousel =======================
*/
$('.owl-market').owlCarousel({
      loop:true,
      margin:10,
      responsiveClass:true,
      nav : false,
      autoplay: true,
      autoplayTimeout : 3000,
      dots : false,
      responsive:{
          0:{
              items:2,
          },
          576:{
              items:3,
          },
          768:{
              items:3,
          },
          992:{
              items:4,
          },
          1200:{
              items:5,
          },
          1400:{
              items:6,
          },
      }
});

/*
      ============================== nva menu =============================
*/


const collapseBtn  = document.querySelector(".collapse-btn");
const header       = document.querySelector(".header");
const logo         = document.querySelector(".logo");
const headerWraper = document.querySelector(".header-wraper");
const backToTop    = document.querySelector(".backtotop");

collapseBtn.addEventListener('click',toggleMenu);

function toggleMenu(){
      
      var wraperRect = headerWraper.getBoundingClientRect();
      var logoRect   = logo.getBoundingClientRect();
      var headerRect = header.getBoundingClientRect();

      header.classList.toggle("toggle-menu");

      if(headerRect.height > logoRect.height){
            header.style.height = `${logoRect.height}px`;
      }else{
            header.style.height = `${wraperRect.height}px`;
      }
      
}

window.addEventListener("resize",e => {

      var wraperRect = headerWraper.getBoundingClientRect();
      var headerRect = header.getBoundingClientRect();
      
      if(header.classList.contains("toggle-menu") && wraperRect.height != headerRect.height){
            header.style.height = `${wraperRect.height}px`;
      }

});

const dropExpandWraper = document.querySelectorAll(".menu-item-has-children > a");

dropExpandWraper.forEach(item => {
      var i = document.createElement('i');
      i.className ='fas fa-angle-down dropdown-expand';
      item.appendChild(i);
});

const dropExpand = document.querySelectorAll(".dropdown-expand");
dropExpand.forEach(item => {
      item.addEventListener("click",e => {
           if(window.innerWidth < 992){
                  e.preventDefault();
                  const dropdown   = document.querySelectorAll(".sub-menu");

                  dropdown.forEach(dropitem => {
                        dropitem.style.height = '0';
                        header.style.height = `${header.getBoundingClientRect().height - 200}px`;
                  });

                  var currentDropdown = item.parentElement.parentElement.querySelector(".sub-menu");
                  if(currentDropdown.getBoundingClientRect().height == 0){
                        currentDropdown.style.overflowY = 'scroll';
                        currentDropdown.style.height = '200px';
                        header.style.height = `${header.getBoundingClientRect().height + 200}px`;
                  }
           }
      });
})


/*
      ================================= nav menu end =============================
*/

/*
      ================================= sticky navbar =============================
*/


var prevScrollPos = window.pageYOffset;
window.addEventListener("scroll",() => {

      var headerRect = header.getBoundingClientRect();

      let currentScrollPos = window.pageYOffset;

      if(prevScrollPos > currentScrollPos){
            if(window.innerWidth >= 992){
                  header.style.transform = `translateY(-45px)`;
            }else{
                  header.style.transform = `translateY(0)`;
            }
      }else{
            header.style.transform = `translateY(-${headerRect.height + 10}px)`;   
      }
      if(currentScrollPos === 0){
            header.style.transform = `translateY(0)`;
      }
      // show back to top button
      if(currentScrollPos > headerRect.height){
            backToTop.classList.add("show");
      }else{
            backToTop.classList.remove("show");
      }
      prevScrollPos = currentScrollPos;
});

/*
      =========================== sticky navbar end =======================
*/

/*
      =========================== back to top =======================
*/


backToTop.addEventListener("click",e => {

      e.preventDefault();
      var id = backToTop.getAttribute("href").slice(1);
      var target = document.getElementById(id);

      scrollTo({
            top  : target.getBoundingClientRect().top,
            left : 0
      });

});

/*
      ============================ back to top end ============================
*/

/*
      ============================ tab ============================
*/

const tabBtns = document.querySelectorAll(".tab-btn");
const tabItems = document.querySelectorAll(".tab-item");

tabBtns.forEach(element => {

      element.addEventListener("click",function(){

            var id = this.dataset.id;
            var target = document.getElementById(id);

            for (let i = 0; i < tabItems.length; i++) {
                  tabItems[i].classList.remove('active-item');
            }
            for (let i = 0; i < tabBtns.length; i++) {
                  tabBtns[i].classList.remove('active-btn');
            }
            target.classList.add('active-item');
            this.classList.add("active-btn");
      });

});

/* 
      ================================ tab end ====================================
*/


/* 
      ================================ pagination ====================================
*/
//all portfolios
const getPortfolios = (url) => {
      var xmlHttp = new XMLHttpRequest;
      var portfolioManage = new Manageportfolio;
      xmlHttp.onloadstart = () => portfolioManage.placeholder(true);
      xmlHttp.onload = portfolioManage.placeholder(false);

      xmlHttp.onreadystatechange = function(){
            if(this.readyState === 4 && this.status === 200){

                  portfolioManage = new Manageportfolio(JSON.parse(this.responseText));
                  portfolioManage.setFilterBtn();
                  portfolioManage.filterPortfolio();

            }
      }
      xmlHttp.open('POST',url);
      xmlHttp.setRequestHeader("content-type","application/x-www-form-urlencoded");
      xmlHttp.send('action=get_ajax_posts');
}

class Manageportfolio{

      constructor(portfolios=[]){
            this.portfolios         = portfolios;
            this.pagiWraper         = this._('paginations');
            this.buttonWraper       = this._('filter-button');
            this.portfolioWraper    = this._('portfolio-item');
            this.filterBtn          = null;
            this.singleItem         = null;
            this.controllBtn        = null;
            this.numberBtn          = null;
            this.category           = "all";
            this.setter();
      }
      setter(){
            this.pages              = 1;
            this.currentPage        = 1;
            this.nextPage           = 2;
            this.limit              = parseInt(this.pagiWraper.dataset.limit);
            this.offset             = (this.currentPage - 1) * this.limit;
            this.lastNextAction     = false;
      }
      /**
       * 
       * @param {string} cls 
       * @returns document.querySelctor('.cls');
      */
      _(cls){
            return document.querySelector(`.${cls}`);
      }
      /**
       * 
       * @param {string} cls 
       * @returns document.querySelctorAll('.cls');
      */
      _all(cls,object=document){
            return object.querySelectorAll(`.${cls}`);
      }

      /**
       * @param {null}
       * @returns true
       * @description set filter button when load the page
      */
      setFilterBtn(){

            const categories = new Set();
            this.portfolios.map(item => {
                  categories.add(item.portfolio_category[0]);
            });
            var list = '<ul>';
            if(categories.size !== 0){
                  
                  list += '<li><button class="filter-btn active-fbtn" data-category="all">All</button></li>';
                  categories.forEach(item => {
                        list += `<li><button class="filter-btn" data-category="${item}">${item}</button></li>`
                  });
            }
            list += '</ul>';

            this.buttonWraper.innerHTML = list;

            //add all buttons to filter button variabe
            this.filterBtn = this._all('filter-btn');
            if(this.filterBtn.length !== 0) {
                  this.filterBtn.forEach(btn => {
                        btn.addEventListener("click",() => {
                              this.filterPortfolioByBtn(btn);
                        });
                  });
            }
            return true;
      }

      /**
       * @param {null}
       * @returns true
       * @description filter portfolios by its category
       */

      filterPortfolio(category="all"){

            var portfolio = this.portfolios.map(item => {
                  if(item.portfolio_category.indexOf(category) !== -1 || category == 'all'){
                        return `<div class="single-item">
                                          <div class="item-thumb">
                                                ${item.portfolio_image}
                                          </div>
                                          <div class="item-btns">
                                                <ul>
                                                      <li>
                                                            <a target="blank" href="${item.portfolio_live_link}" class="item-btn">
                                                                  <i class="fas fa-link"></i>
                                                            </a>
                                                      </li>
                                                      <li>
                                                            <a target="blank" href="${item.portfolio_link}" class="item-btn">
                                                                  <i class="fas fa-plus"></i>
                                                            </a>
                                                      </li>
                                                      <li>
                                                            <button class="item-btn" onclick="expandPortfolio(this)">
                                                                  <i class="fas fa-expand"></i>
                                                            </button>
                                                      </li>
                                                </ul>
                                          </div>
                                          <div class="portolio-title">${item.portfolio_title}</div>
                                    </div>`;
                  }
                  return "";
            }).filter((val) => val != "");
      
            this.pages = Math.ceil(portfolio.length / this.limit);
            
            this.pages > 1 ? this.pagination() : this.pagiWraper.innerHTML = '';

            portfolio = portfolio.slice(this.offset,this.limit + this.offset);
            
            this.portfolioWraper.innerHTML = portfolio.join("");
            
            this.singleItem = this._all("single-item");

            return true;
      }   

      /**
       * @params {null}
       * @return true
       * @description filter posts by button clicking
      */

      filterPortfolioByBtn(btn){
            this.setter();
            this.category = btn.dataset.category;
            this.filterBtn.forEach(b => {
                  b.classList.remove("active-fbtn");
            });
            btn.classList.add("active-fbtn");
            this.filterPortfolio(this.category);
            return true;
      }

      /**
       * @params {null}
       * @return true
       * @description set pagination
      */

      pagination(){
      
            var pagination = document.createElement("ul");
            pagination.innerHTML =`
                  <li>
                        <button data-controll="prev" class="pagi-btn controll-btn" ${this.currentPage <= 1 ? 'disabled' : ''}>
                              <i class="fas fa-angle-left"></i>
                        </button>
                  </li>
                  ${(this.currentPage > 2) ? ' <li><i class="fas fa-ellipsis-h"></i></li>' : ''}
                  <li>
                        <button data-number="${this.nextPage - 1}" data-cond="false" class="number-btn pagi-btn ${(this.lastNextAction == false) ? 'active-page':''}" >${this.nextPage - 1}</button>
                  </li>
                  <li>
                        <button data-number="${this.nextPage}" data-cond="true" class="number-btn pagi-btn ${(this.lastNextAction == true) ? 'active-page' : ''}" >${this.nextPage}</button>
                  </li>
                  ${(this.pages > 2 && this.pages !== this.currentPage) ? '<li><i class="fas fa-ellipsis-h"></i></li>' : ''}
                  <li>
                        <button data-controll="next" ${this.currentPage === this.pages ? 'disabled' : ''} class="pagi-btn controll-btn">
                              <i class="fas fa-angle-right"></i>
                        </button>
                  </li>
            `;

           this.controllBtn = this._all("controll-btn",pagination);
           this.numberBtn   = this._all("number-btn",pagination);

            //add listener to every controll btn
            if(this.controllBtn.length !== 0){
                  this.controllBtn.forEach(btn => {
                        btn.addEventListener("click",() => {
                              this.controllPage(btn,btn.dataset.controll);
                        });
                  });
            }

            //add listener to every number btn
            if(this.numberBtn.length !== 0){
                  this.numberBtn.forEach(btn => {
                        btn.addEventListener("click",() => {
                              var dataset = btn.dataset;
                              this.changePage(btn,dataset.number,dataset.cond);
                        });
                  });
            }

            this.pagiWraper.innerHTML = '';
            this.pagiWraper.appendChild(pagination);

            return true;
      }

      /**
       * @param {No Param}
       * @return true
       * @description controll pagination
      */

      controllPage(btn,status){

            if(status  == 'next'){
      
                  ++this.currentPage;
                  this.nextPage = 1 + this.currentPage;
                  this.lastNextAction = false;
                  if(this.currentPage == this.pages){
                        this.lastNextAction = true;
                  }
                  if(this.nextPage > this.pages){
                        this.nextPage = this.pages;
                        this.currentPage = this.nextPage - 1;
                  }
                  if(this.lastNextAction){
                        this.currentPage = this.pages;
                  }                  
      
            }else{
      
                  this.lastNextAction = true;
                  if(this.currentPage != 2){
                        this.nextPage = --this.currentPage;
                  }else{
                        this.lastNextAction = false;
                        this.currentPage = 1;
                  }
            }
            this.showItemsByCurrentPage();

            return true;
      
      }


      /**
       * @param {No Param}
       * @return {bool} true
       * @description change page by number clicking
      */
      
      changePage(btn,page,action){

            
            this.numberBtn.forEach(element => {
                  element.classList.remove("active-page");
            });

            btn.classList.add("active-page");
            
            this.currentPage = parseInt(page);

            this.lastNextAction = action == 'true' ? true : false;
            
            this.showItemsByCurrentPage();
            
            return true;
      }

      /**
       * @param {No Param}
       * @return {bool} true
       * @description show portfolio item by current page
      */
      
      showItemsByCurrentPage(){
            this.offset = (this.currentPage - 1) * this.limit;
            this.filterPortfolio(this.category);
      }

      /**
       * @param {No Param}
       * @return {bool} true
       * @description setplacehold before load end
      */

      placeholder(loading=true){
            if(loading){
                  var buttons    = 5;
                  var singleItem = 8;
                  var list       = '<ul>';
                  for (let index = 0; index < buttons; index++) {
                        list += `<li><button class="placeholder"></button></li>`;
                  }
                  list += '</ul>';
                  var singleElement = '';
                  for (let index = 0; index < singleItem; index++) {
                        singleElement += '<div class="single-item placeholder"></div>';
                  }
                  this.buttonWraper.innerHTML    = list;
                  this.portfolioWraper.innerHTML = singleElement;
            }
      }
}

/*
      ================================= expand images ==================================
*/
function expandPortfolio(btn){
      var img = btn.parentElement.parentElement.parentElement.previousElementSibling.querySelector("img").getAttribute("src");
      var wraper = document.createElement('div');
      wraper.classList.add("expanded_wraper");
      wraper.classList.add("img-visible");

      wraper.innerHTML = `
      <div class="expand-img">
            <img src="${img}" alt=""/>
            <button class="close-img" onclick="removePopup(this)">
                  <i class="fas fa-times"></i>
            </button>
      </div>`;

      document.body.appendChild(wraper);
      
}

function removePopup(btn){
      btn.parentElement.style.transform = 'scale(0)';
      btn.parentElement.parentElement.style.opacity = '0';
      setTimeout(() => {
            document.body.removeChild(btn.parentElement.parentElement);
      }, 200);
}

// back functionality of 404 page
const backBtn = document.querySelector(".back-btn");
backBtn.addEventListener("click",goBack);
function goBack(e){
      window.history.back();
}