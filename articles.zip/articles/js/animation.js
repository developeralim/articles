

var animateClasses = [
      'zoom-out',
      'top-fade',
      'left-fade',
      'right-fade',
      'bottom-fade',
      'fade-in',
      'zoom-in',
      'top-to-bottom',
      'bottom-to-top',
      'bounce-top',
      'bounce-bottom',
      'bounce-left',
      'bounce-right',
      'left-top-bottom',
      'left-bottom-top',
      'right-top-bottom',
      'right-bottom-top'
];

var animateElemets = new Array;
(function(){

      for (const cls of animateClasses) {
            var elemets = _all(cls);
            elemets.forEach(sinleElement => {
                  if(checkPostion(sinleElement) === 'Bottom' || checkPostion(sinleElement) === 'In viewport'){
                        animateElemets.push(sinleElement)
                  }else{
                        addClass(sinleElement,'default');
                  }
            });
      }

}());

window.addEventListener("load",e => {
      document.body.style.overflowX = 'hidden';
      if(animateElemets.length !== 0){
            animateElemets.forEach(element => checkAnimateCalss(element));
      }
});

function checkAnimateCalss(element){
      var rect = element.getBoundingClientRect();
      if(isInViewport(element)){ 

            if($(element,'top-fade')){
                  css(element,{
                        transform : 'translateY(-100%)',
                  });
                  addClass(element,'tf');

            }else if($(element,'left-fade')){

                  css(element,{
                        transform : 'translateX(-100%)',
                  });
                  addClass(element,'lf');

            }else if($(element,'right-fade')){

                  css(element,{
                        transform : 'translateX(100%)',
                  });
                  addClass(element,'rf');

            }else if($(element,'bottom-fade')){

                  css(element,{
                        transform : 'translateY(100%)',
                  });
                  addClass(element,'bf');

            }else if($(element,'left-top-bottom')){
                 
                  css(element,{
                        transform: `rotate(-90deg) translate(50%,-${rect.width / 2}px)`,
                  });
                  addClass(element,'ltb');

            }else if($(element,'left-bottom-top')){

                  css(element,{
                        transform: `rotate(90deg) translate(50%,0px)`,
                  });
                  addClass(element,'lbt');

            }else if($(element,'right-top-bottom')){

                  css(element,{
                        transform: `rotate(90deg) translate(-50%,-${rect.width / 2}px)`,
                  });
                  addClass(element,'rtb');

            }else if($(element,'right-bottom-top')){

                  css(element,{
                        transform: `rotate(-90deg) translate(-50%,${rect.width / 2}px)`,
                  });
                  addClass(element,'rbt');

            }else if($(element,'zoom-in')){

                  addClass(element,'zi');

            }else if($(element,'zoom-out')){

                  css(element,{
                        transform : 'scale(1.2)',
                  })
                  addClass(element,'zo');

            }else if($(element,'fade-in')){

                  addClass(element,'fi');

            }else if($(element,'bounce-left')){

                  addClass(element,'bl');

            }else if($(element,'bounce-right')){

                  addClass(element,'br');

            }else if($(element,'bounce-top')){

                  addClass(element,'bt');

            }else if($(element,'bounce-bottom')){

                  addClass(element,'bb');

            }
            
            animateElemets = animateElemets.filter(function(value){
                  if(value == element){
                        return false;
                  }else{
                        return true;
                  }
            });

      }
}

/*
      ================================= progress bar start =================================
*/

const skillItems = document.querySelectorAll(".skill-item .p");

window.onscroll = function (){
      skillItems.forEach(item => {
            
            if(item.dataset.repeate == 'true'){
                  if(isInViewport(item)){
                        
                        item.setAttribute('data-repeate','false');
                        const width = item.dataset.width;
                        const bg = item.dataset.bg;
                        let init = 1;
                        
                        setInterval(() => {
                              if(init !== parseInt(width)){
                                    init++;
                                    item.style.width = `${init}%`;
                                    item.style.background = `${bg}`;
                                    item.setAttribute('data-width',init);
                              }
                        },1);
      
                  }
            }

      });
}

/* 
      ================================ progress bar end ====================================
*/


function $(element,cls){
      return element.classList.contains(cls)
}
function addClass(element,cls,timeout = 200){
      setTimeout(() => element.classList.add(cls),timeout);
}
function css(element,obj){
      for (const key in obj) {
            if (Object.hasOwnProperty.call(obj, key)) {
                  element.style[key] = obj[key];
            }
      }
}
window.addEventListener("scroll",e => {

      animateElemets.forEach(element => {
            
            if(isInViewport(element)){
                  checkAnimateCalss(element);
                  animateElemets = animateElemets.filter(function(value){
                        if(value == element){
                              return false;
                        }else{
                              return true;
                        }
                  });
            }

      })

});

function checkPostion(element){

      var rect = element.getBoundingClientRect();
      if(rect.top < 0){
            return 'Top';
      }else if(rect.bottom > (window.innerHeight || document.documentElement.clientHeight)){
            return 'Bottom';
      }else{
            return 'In viewport';
      }

}

function isInViewport(element){
      var rect = element.getBoundingClientRect();
      return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.right <= (window.innerWidth + rect.width || document.documentElement.innerWidth + rect.width) &&
            rect.bottom <= (window.innerHeight + rect.height || document.documentElement.innerHeight + rect.height)
      );
}

function _(cls){
      return document.querySelector(`.${cls}`);
}
function _all(cls){
      return document.querySelectorAll(`.${cls}`);
}


/*
      ============================== blog carousel =======================
*/
